#pragma once
#include <cstdint>
using Uint8 = uint8_t; using Uint32 = uint32_t; using Sint16 = int16_t;
struct SDL_Color { Uint8 r,g,b,a; };
struct SDL_Rect { int x,y,w,h; };
struct SDL_Renderer {}; struct SDL_Window {}; struct SDL_Texture {}; struct SDL_GameController {}; struct SDL_Joystick {};
using SDL_JoystickID = int32_t;
enum SDL_GameControllerButton { SDL_CONTROLLER_BUTTON_A, SDL_CONTROLLER_BUTTON_B, SDL_CONTROLLER_BUTTON_X, SDL_CONTROLLER_BUTTON_Y, SDL_CONTROLLER_BUTTON_BACK, SDL_CONTROLLER_BUTTON_START, SDL_CONTROLLER_BUTTON_DPAD_UP, SDL_CONTROLLER_BUTTON_DPAD_DOWN, SDL_CONTROLLER_BUTTON_DPAD_LEFT, SDL_CONTROLLER_BUTTON_DPAD_RIGHT, SDL_CONTROLLER_BUTTON_LEFTSHOULDER, SDL_CONTROLLER_BUTTON_RIGHTSHOULDER };
enum SDL_GameControllerAxis { SDL_CONTROLLER_AXIS_LEFTX, SDL_CONTROLLER_AXIS_LEFTY };
struct SDL_Keysym { int sym; }; struct SDL_KeyboardEvent { int repeat; SDL_Keysym keysym; };
struct SDL_ControllerDeviceEvent { int which; }; struct SDL_ControllerButtonEvent { int which; uint8_t button; }; struct SDL_ControllerAxisEvent { int which; uint8_t axis; Sint16 value; };
union SDL_Event { uint32_t type; SDL_KeyboardEvent key; SDL_ControllerDeviceEvent cdevice; SDL_ControllerButtonEvent cbutton; SDL_ControllerAxisEvent caxis; };
constexpr Uint32 SDL_INIT_VIDEO=1, SDL_INIT_GAMECONTROLLER=2, SDL_INIT_EVENTS=4;
constexpr int SDL_WINDOWPOS_CENTERED=0, SDL_WINDOW_RESIZABLE=1, SDL_WINDOW_ALLOW_HIGHDPI=2;
constexpr Uint32 SDL_RENDERER_ACCELERATED=1, SDL_RENDERER_PRESENTVSYNC=2, SDL_RENDERER_SOFTWARE=4;
constexpr int SDL_ENABLE=1, SDL_TEXTUREACCESS_STREAMING=1;
constexpr Uint32 SDL_PIXELFORMAT_ARGB8888=0x16362004u;
constexpr int SDLK_UP=1, SDLK_DOWN=2, SDLK_LEFT=3, SDLK_RIGHT=4, SDLK_RETURN=5, SDLK_SPACE=6, SDLK_ESCAPE=7;
#define SDL_HINT_RENDER_SCALE_QUALITY "SDL_RENDER_SCALE_QUALITY"
constexpr Uint32 SDL_QUIT=10, SDL_KEYDOWN=11, SDL_CONTROLLERDEVICEADDED=12, SDL_CONTROLLERDEVICEREMOVED=13, SDL_CONTROLLERBUTTONDOWN=14, SDL_CONTROLLERBUTTONUP=15, SDL_CONTROLLERAXISMOTION=16;
int SDL_Init(Uint32); void SDL_Quit(); int SDL_SetHint(const char*,const char*);
SDL_Window* SDL_CreateWindow(const char*,int,int,int,int,Uint32); void SDL_DestroyWindow(SDL_Window*);
SDL_Renderer* SDL_CreateRenderer(SDL_Window*,int,Uint32); void SDL_DestroyRenderer(SDL_Renderer*);
SDL_Texture* SDL_CreateTexture(SDL_Renderer*,Uint32,int,int,int); void SDL_DestroyTexture(SDL_Texture*);
int SDL_UpdateTexture(SDL_Texture*,const SDL_Rect*,const void*,int); int SDL_RenderCopy(SDL_Renderer*,SDL_Texture*,const SDL_Rect*,const SDL_Rect*);
int SDL_RenderSetLogicalSize(SDL_Renderer*,int,int); int SDL_GameControllerEventState(int);
int SDL_NumJoysticks(); int SDL_IsGameController(int); SDL_GameController* SDL_GameControllerOpen(int);
SDL_Joystick* SDL_GameControllerGetJoystick(SDL_GameController*); SDL_JoystickID SDL_JoystickInstanceID(SDL_Joystick*);
const char* SDL_GameControllerName(SDL_GameController*); void SDL_GameControllerClose(SDL_GameController*);
int SDL_PollEvent(SDL_Event*); void SDL_Delay(Uint32);
int SDL_SetRenderDrawColor(SDL_Renderer*,Uint8,Uint8,Uint8,Uint8); int SDL_RenderClear(SDL_Renderer*);
int SDL_RenderFillRect(SDL_Renderer*,const SDL_Rect*); int SDL_RenderDrawRect(SDL_Renderer*,const SDL_Rect*);
int SDL_RenderDrawLine(SDL_Renderer*,int,int,int,int); void SDL_RenderPresent(SDL_Renderer*);
