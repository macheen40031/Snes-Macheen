# Changelog — Snes-Macheen v1.14

## 1.14 — Serial Joypad Integration

- Connected controller mappings to SNES serial joypad ports at $4016/$4017.
- Added two independent 12-button serial state streams (P1/P2).
- Implemented strobe-high live B-button reads and falling-edge controller latching.
- Implemented serial shifting, trailing logic-high reads, and upper system-bank I/O mirrors.
- SDL controller events now publish mapped button states into the active emulator session.

- Preserved the earlier regression suite.
- Passed strict clean host build and regression tests.
- Passed AddressSanitizer and UndefinedBehaviorSanitizer.
- Android project structure/static checks passed (30).
- Real Android APK build and SDL2 native link not run in this environment.
